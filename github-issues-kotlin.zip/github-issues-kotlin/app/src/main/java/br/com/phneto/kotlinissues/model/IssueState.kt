package br.com.phneto.kotlinissues.model

enum class IssueState(val state: String) {
    ALL("all"),
    OPEN("open"),
    CLOSED("closed")

}
package br.com.phneto.kotlinissues.util

class Constants private constructor() {

    companion object {
        val ISSUE_KEY = "ISSUE_KEY"
    }
}